# cache-sim
A cache simulator written for my Advanced Computer Architecture class at UCF.

## Dependencies

This project was built with python version `Python 3.12.0b3`.